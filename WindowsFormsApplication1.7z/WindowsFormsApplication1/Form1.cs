﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            int[,] Weights = new int[4, 4];
            int[,] Amount = new int[4, 4];
            int[] Bj = new int[4];
            int[] Ai = new int[4];
            int[] PotencialA = new int[4];
            int[] PotencialB = new int[4];
            int[] tempBj = new int[4];
            int[] tempAi = new int[4];
            int Str = -1, Stlb = -1;

            try
            {
                Weights[0, 0] = int.Parse(textBox1.Text);
                Weights[0, 1] = int.Parse(textBox8.Text);
                Weights[0, 2] = int.Parse(textBox12.Text);
                Weights[0, 3] = int.Parse(textBox16.Text);
                Weights[1, 0] = int.Parse(textBox2.Text);
                Weights[1, 1] = int.Parse(textBox7.Text);
                Weights[1, 2] = int.Parse(textBox11.Text);
                Weights[1, 3] = int.Parse(textBox15.Text);
                Weights[2, 0] = int.Parse(textBox3.Text);
                Weights[2, 1] = int.Parse(textBox6.Text);
                Weights[2, 2] = int.Parse(textBox10.Text);
                Weights[2, 3] = int.Parse(textBox14.Text);
                Weights[3, 0] = int.Parse(textBox4.Text);
                Weights[3, 1] = int.Parse(textBox5.Text);
                Weights[3, 2] = int.Parse(textBox9.Text);
                Weights[3, 3] = int.Parse(textBox13.Text);

                Bj[0] = int.Parse(textBox20.Text);
                Bj[1] = int.Parse(textBox19.Text);
                Bj[2] = int.Parse(textBox18.Text);
                Bj[3] = int.Parse(textBox17.Text);

                Ai[0] = int.Parse(textBox28.Text);
                Ai[1] = int.Parse(textBox27.Text);
                Ai[2] = int.Parse(textBox26.Text);
                Ai[3] = int.Parse(textBox25.Text);
            }
            catch (Exception ED)
            { MessageBox.Show(Convert.ToString(ED)); }

            if (!check(ref Ai, ref Bj)) { MessageBox.Show("Задача не может быть решена так как суммы А и В не сходятся."); return; }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                    Amount[i, j] = 0;
                tempAi[i] = Ai[i];
                tempBj[i] = Bj[i];
                PotencialB[i] = -300;
                PotencialA[i] = -300;
            }
            Show_matrix(ref Weights, "Введённая матрица");



            for (; !summIsZero(ref tempAi) && !summIsZero(ref tempBj);)
            {
                findmin(ref Weights, ref Amount, ref Str, ref Stlb, ref tempAi, ref tempBj);
                if (Str == -1 && Stlb == -1) break;

                if (tempAi[Str] > tempBj[Stlb])
                {
                    Amount[Str, Stlb] = tempBj[Stlb];
                    tempAi[Str] -= tempBj[Stlb];

                    tempBj[Stlb] = 0;

                }
                else
                {
                    Amount[Str, Stlb] = tempAi[Str];
                    tempBj[Stlb] -= tempAi[Str];
                    tempAi[Str] = 0;

                }
            }
            //  trying to find potencials
            for (;;)
            {
                PotencialA[0] = 0;
                find_cooficients(ref Amount, ref Weights, ref PotencialA, ref PotencialB);
                Show_matrix(ref Amount, "Матрица после преобразований");
                Show_cooficients(ref PotencialA, ref PotencialB);
                int X=-1,Y=-1; 
                if (check_for_optimal(ref Amount, ref Weights, ref PotencialA, ref PotencialB,ref X,ref Y))
                    break;
                graph solex = new graph(X, Y);
                solex.findChild(ref Weights, ref Amount);
                X = 0;
                break;
            }


        }


        public static int[,] solution = new int[16,2];

        private class graph
        {
            public static int STR, STLB;
            int depth;
            public static int[,] way = new int[16,2];
            public int fatherA, fatherB,a,b;
            public string state;
            public static bool cycle_is_finded;
            public  graph[] child;
            public int num_of_childs = 0;
            bool up=false, down = false, right = false, left = false;

            public graph(int A,int B)
            {
                STR = A; STLB = B;
                a = A; b = B;
                cycle_is_finded = false;
                depth = 1;
            }
            public graph(int A,int B,int FatherA,int FatherB,int Depth, string s)
            {
                state = s;
                switch (state)
                {
                    case "up":
                        { down = true; up = true; break; }
                    case "down":
                        { up = true; down = true; break; }
                    case "left":
                        { right = true; left = true; break; }
                    case "right":
                        { left = true; right = true; break; }
                }
                fatherA = FatherA;
                fatherB = FatherB;
                a = A;
                b = B;
                depth = Depth + 1;

            }
            public void solution_found()
            {
                for(int i = 0;i<16;i++)
                {
                    if (i<depth)
                    {
                        solution[i, 0] = way[i, 0];
                        solution[i, 1] = way[i, 1];
                   }
                    else
                    {
                        solution[i, 0] = -300;
                        solution[i, 1] = -300;
                    }
                }
            }

             public bool child_exists(ref int[,] Weights, ref int[,] Amount)
           {
                //UP   
                  if(!up)
                    for (int i = a - 1; i >= 0; i--)
                        if ((Amount[i, b] != 0 && !(i == fatherA && b == fatherB)) || (i == STR && b == STLB && depth > 3))
                    {
                        if (i == STR && b == STLB)
                        {
                            way[depth - 1, 0] = i;
                            way[depth - 1, 1] = b;
                            cycle_is_finded = true;
                            solution_found();
                        }
                        state = "up";
                        return true;
                    }
                    else if (i == fatherA && b == fatherB) break;
                // DOWN
                if (!down)
                        for (int i = a + 1; i < 4; i++)
                    if ((Amount[i, b] != 0 && !(i == fatherA && b == fatherB))|| (i == STR && b == STLB && depth > 3))
                    {
                        if (i == STR && b == STLB)
                        {
                            way[depth-1, 0] = i;
                            way[depth-1, 1] = b;
                            cycle_is_finded = true;
                            solution_found();
                        }
                        state = "down";
                        return true;
                    }
                    else if (i == fatherA && b == fatherB) break;
                //Right
               if (!right)
                        for (int i = b + 1; i < 4; i++)
                    if ((Amount[a, i] != 0 && !(a == fatherA && i == fatherB))|| (i == STR && b == STLB && depth > 3))

                    {
                        if (a == STR && i == STLB)
                        {
                            way[depth-1, 0] = a;
                            way[depth-1, 1] = i;
                            cycle_is_finded = true;
                            solution_found();
                        }
                        state = "right";
                        return true;
                    }
                    else if (a == fatherA && i == fatherB) break;
                //Left
                if (!left)
                        for (int i = b - 1; i >= 0; i--)
                    if ((Amount[a, i] != 0 && !(a == fatherA && i == fatherB))|| (i == STR && b == STLB && depth > 3))
                    {
                        if (a == STR && i == STLB)
                        {
                            way[depth-1, 0] = a;
                            way[depth-1, 1] = i;
                            cycle_is_finded = true;
                            solution_found();
                        }
                        state = "left";
                        return true;
                    }
                    else if (a == fatherA && i == fatherB) break;
                state = "";
                return false;
            }

            public void findChild(ref int[,] Weights, ref int[,] Amount)
            {
                for(; !cycle_is_finded&&child_exists(ref Weights, ref Amount);)
                {
                    switch (state)
                    {
                        case "up":
                            {
                                for (int i = a - 1; i >= 0; i--)
                                    if (Amount[i, b] != 0 && !cycle_is_finded)
                                    {
                                            num_of_childs++;
                                        up = true;
                                        way[depth - 1, 0] = i;
                                        way[depth - 1, 1] = b;
                                        Array.Resize(ref child, num_of_childs);
                                            child[num_of_childs - 1] = new graph(i,b,a,b,depth,state);
                                            child[num_of_childs - 1].findChild(ref Weights, ref Amount);
                                    }

                                break;
                            }
                        case "down":
                                {
                                    for (int i = a + 1; i <4 ; i++)
                                        if (Amount[i, b] != 0 && !cycle_is_finded)
                                        {
                                        down = true;
                                        num_of_childs++; 
                                        way[depth - 1, 0] = i;
                                        way[depth - 1, 1] = b;
                                        Array.Resize(ref child, num_of_childs);
                                            child[num_of_childs - 1] = new graph(i, b, a, b, depth, state);
                                            child[num_of_childs - 1].findChild(ref Weights, ref Amount);
                                        }
                                    break;
                                }
                        case "right":
                                {
                                    for (int i = b + 1; i <4 ; i++)
                                        if (Amount[a, i] != 0 && !cycle_is_finded)
                                        {
                                        right = true;
                                        num_of_childs++; 
                                        way[depth - 1, 0] = a;
                                        way[depth - 1, 1] = i;
                                       Array.Resize(ref child, num_of_childs);
                                            child[num_of_childs - 1] = new graph(a, i, a, b, depth, state);
                                            child[num_of_childs - 1].findChild(ref Weights, ref Amount);
                                        }
                                    break;
                                }
                        case "left":
                                {
                                    for (int i = b - 1; i >=0; i--)
                                        if (Amount[a, i] != 0 && !cycle_is_finded)
                                        {
                                        left = true;
                                        num_of_childs++;
                                        way[depth - 1, 0] = a;
                                        way[depth - 1, 1] = i;
                                         Array.Resize(ref child, num_of_childs);
                                            child[num_of_childs - 1] = new graph(a, i, a, b, depth, state);
                                            child[num_of_childs - 1].findChild(ref Weights, ref Amount);
                                        }
                                    break;
                                }

                    }
                    
                }
            }
        };

       


        public bool check_for_optimal(ref int[,] Amount, ref int[,] Weights, ref int[] PotencialA, ref int[] PotencialB, ref int X, ref int Y)
        {
            int maxval = -500;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    if (Amount[i, j] == 0 && (Weights[i, j] < PotencialA[i] + PotencialB[j]))
                    {
                        if(maxval< PotencialA[i] + PotencialB[j]- Weights[i, j])
                        {
                            maxval = PotencialA[i] + PotencialB[j] - Weights[i, j];
                            X = i; Y = j;
                        }
                    }
                      

            return (maxval==-500);
        }

        public void find_cooficients(ref int[,] Amount, ref int[,] Weights, ref int[] PotencialA, ref int[] PotencialB)
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                {

                    if (PotencialA[j] != -300 && PotencialB[i] == -300)
                        for (int t = 0; t < 4; t++)
                        {
                            if (Amount[j, t] != 0 && PotencialB[t] == -300 && PotencialA[j] != -300)
                                PotencialB[t] = Weights[j, t] - PotencialA[j];
                        }

                    else if (PotencialB[i] != -300 && PotencialA[j] == -300)
                        for (int t = 0; t < 4; t++)
                        {
                            if (Amount[t, i] != 0 && PotencialA[t] == -300 && PotencialB[i] != -300)
                                PotencialA[t] = Weights[t, i] - PotencialB[i];
                        }
                }
            for (int i = 3; i >= 0; i--)
                for (int j = 3; j >= 0; j--)
                {

                    if (PotencialA[j] != -300 && PotencialB[i] == -300)
                        for (int t = 0; t < 4; t++)
                        {
                            if (Amount[j, t] != 0 && PotencialB[t] == -300 && PotencialA[j] != -300)
                                PotencialB[t] = Weights[j, t] - PotencialA[j];
                        }

                    else if (PotencialB[i] != -300 && PotencialA[j] == -300)
                        for (int t = 0; t < 4; t++)
                        {
                            if (Amount[t, i] != 0 && PotencialA[t] == -300 && PotencialB[i] != -300)
                                PotencialA[t] = Weights[t, i] - PotencialB[i];
                        }
                }
        }
        private bool summIsZero(ref int[] a)
        {
            int summ = 0;
            for (int i = 0; i < 4; i++)
                summ += a[i];
            return summ == 0;
        }
        private void findmin(ref int[,] a, ref int[,] b, ref int str, ref int stlb, ref int[] Arrstr, ref int[] Arrstrb)
        {
            int min = 500000;
            str = -1; stlb = -1;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    if (a[i, j] < min && b[i, j] == 0 && Arrstr[i] != 0 && Arrstrb[j] != 0)
                    { min = a[i, j]; str = i; stlb = j; }
        }
        private bool check(ref int[] a, ref int[] b)
        {
            int A = 0, B = 0;
            for (int i = 0; i < 4; i++)
            {
                A += a[i];
                B += b[i];
            }
            if (A == B) return true;
            return false;
        }
        private void Show_matrix(ref int[,] a, string message)
        {
            String res = "";
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    res += a[i, j] + " ";
                    if (a[i, j] < 10) res += " ";
                }
                res += '\n';
            }
            MessageBox.Show(message + "\n" + res);

        }
        private void Show_cooficients(ref int[] a, ref int[] b)
        {
            String res = "Коофициенты U";
            for (int j = 0; j < 4; j++)
                res += " " + a[j];

            res += "\nКоофициенты V";
            for (int j = 0; j < 4; j++)
                res += " " + b[j];

            MessageBox.Show(res);

        }

    }
}
